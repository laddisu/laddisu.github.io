const express = require('express');
const app = express();
const port = 3000;

app.use(express.json()); // Parse JSON bodies
app.use(express.static('public')); // Serve files from /public folder

let items = []; // In-memory array acting as a database

// GET - Return all items
app.get('/api/items', (req, res) => {
  res.json(items);
});

// POST - Add a new item
app.post('/api/items', (req, res) => {
  const item = req.body;
  if (!item || !item.name) {
    console.error('POST error: Invalid item');
    return res.status(400).json({ error: 'Invalid item data' });
  }
  items.push(item);
  res.status(201).json(item);
});

// PUT - Update an item by index
app.put('/api/items/:index', (req, res) => {
  const index = parseInt(req.params.index);
  const updatedItem = req.body;
  if (index < 0 || index >= items.length) {
    return res.status(404).json({ error: 'Item not found' });
  }
  items[index] = updatedItem;
  res.json(updatedItem);
});

// DELETE - Remove an item by index
app.delete('/api/items/:index', (req, res) => {
  const index = parseInt(req.params.index);
  if (index < 0 || index >= items.length) {
    return res.status(404).json({ error: 'Item not found' });
  }
  const removed = items.splice(index, 1);
  res.json(removed[0]);
});

// Handle 404 errors for unmatched routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
