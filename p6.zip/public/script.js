// Fetch and display the shopping list
async function getItems() {
    const res = await fetch('/api/items');
    const items = await res.json();
    const list = document.getElementById('itemList');
    list.innerHTML = ''; // Clear list
  
    items.forEach((item, index) => {
      const li = document.createElement('li');
  
      const nameSpan = document.createElement('span');
      nameSpan.textContent = item.name;
  
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Delete';
      deleteBtn.onclick = () => deleteItem(index);
  
      li.appendChild(nameSpan);
      li.appendChild(deleteBtn);
  
      list.appendChild(li);
    });
  }
  
  // Add new item
  async function addItem() {
    const input = document.getElementById('itemInput');
    const name = input.value.trim();
    if (!name) return;
  
    await fetch('/api/items', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
  
    input.value = '';
    getItems();
  }
  
  // Delete item
  async function deleteItem(index) {
    await fetch(`/api/items/${index}`, {
      method: 'DELETE'
    });
    getItems();
  }
  
  // Load items on page load
  window.onload = getItems;
  