let startTime = null;
let gameWon = false;
let timerInterval = null;


async function fetchBunnies() {
    const res = await fetch('/bunnies');
    const bunnies = await res.json();
    displayBunnies(bunnies);
}

function displayBunnies(bunnies) {
    const container = document.getElementById('bunny-list');
    container.innerHTML = '';
  
    bunnies.forEach(bunny => {
      const btn = document.createElement('button');
      btn.textContent = `${bunny.name} (${bunny.isHappy ? '😊' : '😢'})`;
      btn.onclick = () => hugBunny(bunny.name);
  
      // 🌍 Random position on the full screen
      const safeTop = 150; // Avoid header overlap
      const safeBottom = 120; // Avoid footer overlap

      const x = Math.random() * (window.innerWidth - 150);  // 150px = button width buffer
      const y = Math.random() * (window.innerHeight - (safeTop + safeBottom)) + safeTop;
  
      btn.style.left = `${x}px`;
      btn.style.top = `${y}px`;
  
      container.appendChild(btn); // append to full page, not just container
    });
  }
  

async function hugBunny(name) {
    const res = await fetch('/hug', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name })
    });
    const data = await res.json();
    alert(data.message);
    
    await fetchBunnies();       // Refresh bunny states
    await checkWinCondition();  // See if game is won
}

async function checkWinCondition() {
    const res = await fetch('/status');
    const data = await res.json();
    const msg = document.getElementById('status-msg');
  
    if (data.allHappy && !gameWon) {
      gameWon = true;
      clearInterval(timerInterval);

      const timeTaken = ((Date.now() - startTime) / 1000).toFixed(2);
      msg.innerHTML = `
        🎉 All bunnies are happy!<br>
        ⏱️ Time: ${timeTaken} seconds.<br>
        <button class="reset-btn" onclick="resetGame()">🔁 Play Again</button>
      `;

    } else if (!data.allHappy) {
      msg.textContent = "❌ Not all bunnies are happy yet...";
    }
  }
  

  window.onload = () => {
    document.getElementById('start-btn').onclick = () => {
      document.getElementById('start-btn').style.display = 'none';
      document.getElementById('timer').textContent = "⏱️ Time: 0.00 seconds";
  
      startTime = Date.now();
      gameWon = false;
  
      // Start the interval that updates the timer
      timerInterval = setInterval(() => {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
        document.getElementById('timer').textContent = `⏱️ Time: ${elapsed} seconds`;
      }, 100); // updates every 100ms for a smoother timer
  
      fetchBunnies();
    };
  };
  
  

  function resetGame() {
    fetch('/reset', { method: 'POST' })
      .then(() => {
        gameWon = false;
        startTime = Date.now();
        document.getElementById('status-msg').textContent = '';
        document.getElementById('timer').textContent = '⏱️ Time: 0.00 seconds';
  
        // Restart the timer
        clearInterval(timerInterval); // just in case
        timerInterval = setInterval(() => {
          const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);
          document.getElementById('timer').textContent = `⏱️ Time: ${elapsed} seconds`;
        }, 100);
  
        fetchBunnies();
      });
  }
  