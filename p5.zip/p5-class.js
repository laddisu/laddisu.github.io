class Bunny {
    constructor(name) {
        this.name = name;
        this.isHappy = false;
        this.hugs = 0;
    }

    // Hug the bunny
    hug() {
        if (!this.isHappy) {
            this.hugs++;
            if (this.hugs >= 1) {
                this.isHappy = true;
            }
            return `${this.name} has been hugged is now happy!`;
        } else {
            return `${this.name} is already happy!`;
        }

    }

    // Check if the bunny is happy or sad
    checkMood() {
        return this.isHappy ? " 😊 Happy" : " 😢 Sad";
    }

    // Describe the bunny
    describe() {
        return `${this.name} is ${this.checkMood()} with ${this.hugs} hugs.`;
    }
}

module.exports ={ Bunny };