const express = require('express');
const app = express();
const port = 4000;

// Import game logic functions
const {
    hugBunny,
    getAllBunnies,
    allBunniesHappy,
    resetGame
  } = require('./p5-game.js');
  

// Middleware to parse JSON in requests
app.use(express.json());

// Serve static files from /public
app.use(express.static('public'));


// GET /bunnies → returns all bunny states
app.get('/bunnies', (req, res) => {
  res.json(getAllBunnies());
});


// GET /status → returns win status
app.get('/status', (req, res) => {
  const win = allBunniesHappy();
  res.json({ allHappy: win });
});


// POST /hug → hugs a bunny by name
app.post('/hug', (req, res) => {
  const { name } = req.body;
  const result = hugBunny(name);
  res.json({ message: result });
});

// POST /reset → resets the game
app.post('/reset', (req, res) => {
  resetGame(); // this resets your bunny states
  res.json({ message: 'Game reset.' });
});



// Start the server
app.listen(port, () => {
  console.log(`🚀 Bunny Hug Game server running at http://localhost:${port}`);
});
