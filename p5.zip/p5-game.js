const { Bunny } = require("./p5-class.js");

const bunnies = [
  new Bunny("Fluffy"),
  new Bunny("Kevin"),
  new Bunny("Cotton"),
  new Bunny("Mochi"),
  new Bunny("Matcha"),
  new Bunny("Sniffles"),
  new Bunny("Tibs"),
  new Bunny("Angel"),
  new Bunny("Mocha"),
];

function hugBunny(name) {
  const bunny = bunnies.find(b => b.name === name);
  if (bunny) {
    return bunny.hug();
  } else {
    return `No bunny found with name ${name}.`;
  }
}

function getAllBunnies() {
  return bunnies.map(({ name, isHappy, hugs }) => ({
    name,
    isHappy,
    hugs
  }));
}

function allBunniesHappy() {
  return bunnies.every(b => b.isHappy);
}

function resetGame() {
  bunnies.forEach(b => {
    b.isHappy = false;
    b.hugs = 0;
  });
}

// Export everything in ONE place
module.exports = {
  hugBunny,
  getAllBunnies,
  allBunniesHappy,
  resetGame
};
