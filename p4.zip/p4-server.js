// Import modules
const express = require('express');
const app = express();
const port = 3000;

// Import your functions from p4-modules.js
const {
  getQuestions,
  getAnswers,
  getQuestionsAnswers,
  getQuestion,
  getAnswer,
  getQuestionAnswer
} = require('./p4-modules');

// Middleware to set JSON MIME type
app.use(express.json());

// Route: GET /cit/question
app.get('/cit/question', (req, res) => {
  res.type('application/json').send(getQuestions());
});

// Route: GET /cit/answer
app.get('/cit/answer', (req, res) => {
  res.type('application/json').send(getAnswers());
});

// Route: GET /cit/questionanswer
app.get('/cit/questionanswer', (req, res) => {
  res.type('application/json').send(getQuestionsAnswers());
});

// Route: GET /cit/question/:number
app.get('/cit/question/:number', (req, res) => {
  const number = parseInt(req.params.number);
  res.type('application/json').send(getQuestion(number));
});

// Route: GET /cit/answer/:number
app.get('/cit/answer/:number', (req, res) => {
  const number = parseInt(req.params.number);
  res.type('application/json').send(getAnswer(number));
});

// Route: GET /cit/questionanswer/:number
app.get('/cit/questionanswer/:number', (req, res) => {
  const number = parseInt(req.params.number);
  res.type('application/json').send(getQuestionAnswer(number));
});

// Catch-all for unmatched routes
app.use((req, res) => {
  res.status(404).type('application/json').send({ error: "Route not found" });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is listening on http://localhost:${port}`);
});
