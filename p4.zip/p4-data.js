// Question and answer data array 
const data = [
    {
      question: "Q1",
      answer: "A1",
    },
    {
      question: "Q2",
      answer: "A2",
    },
    {
      question: "Q3",
      answer: "A3",
    }
];

//Export statement must be below data declaration - no hoisting with const
module.exports =  {
    data,
};