/*
    CIT 281 Project 2
    Name: Lia Addisu
*/

// Returns a random number between min (inclusive) and max (exclusive)
const getRandomInteger = function(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
};

// Returns a single random lowercase letter
const getRandomLetter = function() {
  const alphabet = "abcdefghijklmnopqrstuvwxyz";
  return alphabet[Math.floor(Math.random() * alphabet.length)];
};

// Returns a random-length string between minLength and maxLength
const getRandomString = function(minLength, maxLength) {
  const length = getRandomInteger(minLength, maxLength + 1);
  let result = "";
  for (let i = 0; i < length; i++) {
    result += getRandomLetter();
  }
  return result;
};

// Returns the input string sorted in ascending order
const getSortedString = function(string) {
  return [...string].sort().join('');
};

// Run the program
const randomStr = getRandomString(10, 20);
console.log("Original:", randomStr);
console.log("Sorted:  ", getSortedString(randomStr));