/*
    CIT 281 Project 2
    Name: Lia Addisu
*/

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
  }
  
  // Returns a single random lowercase letter
  function getRandomLetter() {
    const alphabet = "abcdefghijklmnopqrstuvwxyz";
    return alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  
  let result = "";
  
  for (let i = 0; i < getRandomInteger(5, 26); i++) {
    result += getRandomLetter();
  }

  // Returns a random-length string between minLength and maxLength
function getRandomString(minLength, maxLength) {
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    let result = "";
    for (let i = 0; i < length; i++) {
      result += getRandomLetter();
    }
    return result;
  }
  
  console.log(getRandomString(10, 20));


  // Returns a string sorted in ascending order
  function getSortedString(string) {
    return [...string].sort().join('');
  }

const randomStr = getRandomString(10, 20);
console.log("Original:", randomStr);
console.log("Sorted:  ", getSortedString(randomStr));

