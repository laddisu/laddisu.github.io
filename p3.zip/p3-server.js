const express = require("express");
const path = require("path");
const { coinCombo } = require("./p3-module.js");

const app = express();
const PORT = 3000;

// Serve static files from the public folder
app.use(express.static("public"));

// Optional: Explicitly serve index.html at root
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// API endpoint
app.get("/coin", (req, res) => {
  const amount = parseInt(req.query.amount);
  if (isNaN(amount)) {
    return res.status(400).json({ error: "Invalid amount" });
  }
  res.json(coinCombo(amount));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
