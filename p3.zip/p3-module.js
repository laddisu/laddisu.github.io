function coinCombo(amount) {
  const combinations = [];

  for (let dollar = 0; dollar <= amount / 100; dollar++) {
    for (let halfDollar = 0; halfDollar <= amount / 50; halfDollar++) {
      for (let quarter = 0; quarter <= amount / 25; quarter++) {
        for (let dime = 0; dime <= amount / 10; dime++) {
          for (let nickel = 0; nickel <= amount / 5; nickel++) {
            for (let penny = 0; penny <= amount; penny++) {
              const total =
                penny +
                nickel * 5 +
                dime * 10 +
                quarter * 25 +
                halfDollar * 50 +
                dollar * 100;

              if (total === amount) {
                combinations.push({ penny, nickel, dime, quarter, halfDollar, dollar });
              }
            }
          }
        }
      }
    }
  }

  return {
    amount,
    combinations,
    totalCombinations: combinations.length
  };
}

// coinCount: calculates the total value in cents of a given set of coins
function coinCount(coinCounts = {}) {
  const coinValues = {
    penny: 1,
    nickel: 5,
    dime: 10,
    quarter: 25,
    halfDollar: 50,
    dollar: 100
  };

  let total = 0;

  for (const [coin, count] of Object.entries(coinCounts)) {
    if (coinValues.hasOwnProperty(coin)) {
      total += coinValues[coin] * count;
    }
  }

  return total;
}

// Example usage
console.log(coinCount({ penny: 2, nickel: 3, dime: 1 })); // 27

const result = coinCombo(27);
console.log(`Total combinations for 27 cents: ${result.totalCombinations}`);
console.log("Sample combo:", result.combinations[0]);

module.exports = {
  coinCombo,
  coinCount
};