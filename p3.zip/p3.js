// p3.js
const { coinCombo, coinCount } = require("./p3-module.js");

// Get the command-line argument (index 2)
const amount = parseInt(process.argv[2]);

// Validate the input
if (isNaN(amount)) {
  console.log("Please provide a valid number of cents, like: node p3.js 27");
  process.exit(1);
}

const result = coinCombo(amount);

console.log(`\nCombinations for ${amount} cents:`);
console.log(`Total combinations: ${result.totalCombinations}`);
console.log("Sample combination:", result.combinations[0]);
console.log("Value of sample:", coinCount(result.combinations[0]), "cents");
